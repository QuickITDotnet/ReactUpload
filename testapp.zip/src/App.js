import React, { useState, useEffect } from 'react'
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.css';
import "./App.css";

function App() {

  const [loading, setLoading] = useState(false);
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const loadPost = async () => {

      // Till the data is fetch using API
      // the Loading page will show.
      setLoading(true);

      // Await make wait until that
      // promise settles and return its reult
      const response = await axios.get(
        "https://jsonplaceholder.typicode.com/users");

      // After fetching data stored it in posts state.
      setPosts(response.data);

      // Closed the loading page
      setLoading(false);
    }

    // Call the function
    loadPost();
  }, []);

  return (

    <div className="App">
      <h1> Data Table </h1>
      <table className="table">
        <thead className="table-light">
        <tr table-active>
          <th>ID</th>
          <th>Name</th>
          <th>UserName</th>
          <th>Email</th>
          <th>Address</th>
          <th>Geo Location</th>
          <th>Phone</th>
          <th>WebSite</th>
          <th>Company Name</th>
          <th>Company CatchPhrase</th>
          <th>Company bs</th>


        </tr>


        </thead>
        <tbody>
        {

posts.map((item,index) =>
  <tr key={item.id}  className={index %2==0? 'table-primary' : 'table-secondary'} >
    <td>{item.id}</td>
    <td>{item.name}</td>
    <td>{item.username}</td>
    <td>{item.email}</td>
    <td>{item.address.street + ',' + item.address.suite + ',' + item.address.city + ',' + item.address.zipcode}</td>

    <td>{item.address.geo.lat + ',' + item.address.geo.lng}</td>
    <td>{item.phone}</td>
    <td>{item.website}</td>
    <td>{item.company.name}</td>
    <td>{item.company.catchPhrase}</td>
    <td>{item.company.bs}</td>
  </tr>
)
}
        </tbody>
        
      </table>


    </div>

  )
				
}

export default App;
