import { combineReducers } from "redux";
import { contactReducer } from "./contactReducer";
import  counterReducer  from "./countReducer";
 
export default combineReducers({
  contact: contactReducer,
  counter : counterReducer

  
});
