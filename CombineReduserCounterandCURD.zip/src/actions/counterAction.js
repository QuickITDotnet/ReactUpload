
const initialState = {
  counter: {
    count1: 0,
    count2: 0,
  }
  
};

const counterReducer = (state = initialState, action) => {
  debugger;
  switch (action.type) {
    case "INCREMENT":
      return {...state , counter : {
        count1 : state.counter.count1 + 1
      } } 
    case "DECREMENT":
      return {...state , counter : {
        count1 : state.counter.count1 - 1
      } } 
    case "RESET":
      return ({...state , counter : {
        count1 : 0
      } } );
    default:
      return state;
  }
};
export default counterReducer;
